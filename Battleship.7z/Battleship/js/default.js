var app=angular.module('myApp',[]);

app.directive('playArea',function(){
	return{
		templateUrl:'views/gameBoard.html',
		restrict:'E',
		controller:['$scope','$window',function($scope){
			$scope.msg='Hello World';
			$scope.matrix =genrateMatrix(20,20);
			$scope.matrix=allShipGenrator($scope.matrix);
			
		}],
		link:function(scope,elem,attr){
			scope.checkStatus=function(){
				if(angular.element(event.target).hasClass('shipPart')){
					angular.element(event.target).removeClass('shipPart').addClass('hit');
				}
				else if(angular.element(event.target).hasClass('blank')){
					angular.element(event.target).removeClass('shipPart').addClass('miss');
				}
			}
		}	
	}	
});

app.controller('mainCtrl',['$scope',function($scope){

}]);
// **************************************************************************************************************
var shipNo=5;	//Global Intialization of Ship Count


var box=function(i,j,shipPart=null,cssClass='blank') {
			this.x=i;
			this.y=j;
			this.shipPart=shipPart;
			this.cssClass=cssClass;
		}; 
function genrateMatrix(x,y){
	var mat=[];
	for(let i=0;i<x;i++){
		mat[i]=[];
		for(let j=0;j<y;j++){
			mat[i][j]=new box(i,j);
		}
	}
	for(let i=0;i<x;i++){
		mat[0][i].cssClass='border';			//top
		mat[x-1][i].cssClass = 'border';		//bottom
		mat[i][0].cssClass = 'border';			//left
		mat[i][y-1].cssClass = 'border';		//right
	}
	return mat;
};

// JUST ALLOCATNG THE SHIPS RIGHT NOW
function allocateShips(x,y,mat){
	var random = Math.floor(Math.random() * 10);
	if(random>7){								//To Check Left side
		var flag=true;
		for(let i=0;i<shipNo;i++){
			try{
				if(mat[x-i][y].shipPart==null && mat[x-i][y].cssClass!='border'){
					flag= true;
				}else{
					flag= false;
					break;
				}	
			}catch(e){
				return false;
			}
		}
		if(flag){
			for(let i=0;i<shipNo;i++){
				mat[x-i][y].shipPart= true;
				mat[x-i][y].cssClass='shipPart';
			}
		}else{
			return false;
		}
		shipNo=shipNo-1;
		return mat;
	}
	else if(random>4){ 							//To Check Right side
		var flag=true;
		for(let i=0;i<shipNo;i++){
			try{
				if(mat[x+i][y].shipPart==null && mat[x+i][y].cssClass!='border'){
				flag= true;
			}else{
				flag= false;
				break;
			}
			}catch(e){
				return false;
			}
		}
		if(flag){
			for(let i=0;i<shipNo;i++){
				mat[x+i][y].shipPart= true;
				mat[x+i][y].cssClass='shipPart';
			}
		}else{
			return false;
		}
		shipNo=shipNo-1;
		return mat;
	}
	else if(random>=2){							//To Check down side
		var flag=true;
	
		for(let i=0;i<shipNo;i++){
			try{	
				if(mat[x][y+i].shipPart==null && mat[x][y+i].cssClass!='border'){
					flag= true;
				}else{
					flag= false;
					break;
				}
			}catch(e){
				return false;
			}
		}
		if(flag){
			for(let i=0;i<shipNo;i++){
				mat[x][y+i].shipPart= true;
				mat[x][y+i].cssClass='shipPart';
			}
		}else{
			return false;
		}
		shipNo=shipNo-1;
		return mat;
	}
	else{										//To Check Up side
		var flag=true;
		for(let i=0;i<shipNo;i++){
			try{
				if(mat[x][y-i].shipPart==null && mat[x][y-i].cssClass!='border'){
					flag= true;
				}else{
					flag= false;
					break;
				}
			}catch(e){
				return false;
			}
		}
		if(flag){
			for(let i=0;i<shipNo;i++){
				mat[x][y-i].shipPart= true;
				mat[x][y-i].cssClass='shipPart';
			}
		}else{
			return false;
		}
		shipNo=shipNo-1;
		return mat;
	}
}

function genrateShips(mat){
	var x = Math.floor(Math.random() * mat.length);
	var y = Math.floor(Math.random() * mat.length);
	console.log('co->',x,y);
	var ships= allocateShips(x,y,mat);
	console.log('co->',ships);
	if(!ships){
		return genrateShips(mat);
	}
	else{
		return ships;
	}
};
function allShipGenrator(mat){
	var finalMatrix=mat;
	for(let i=0;i<5;i++){
		finalMatrix=genrateShips(finalMatrix);
	}
	return finalMatrix;
}

